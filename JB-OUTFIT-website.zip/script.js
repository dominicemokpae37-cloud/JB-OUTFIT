// JB-OUTFIT storefront — edit products, prices and Paystack key in this file.
const WHATSAPP_NUMBER = "2348062815053";
const PAYSTACK_PUBLIC_KEY = "pk_test_REPLACE_WITH_YOUR_PAYSTACK_PUBLIC_KEY"; // Replace with your own Paystack public key.

const products = [
  {id:1,name:"JB Signature Graphic Tee",category:"tees",price:18000,tag:"BESTSELLER",desc:"Everyday statement piece",image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=85"},
  {id:2,name:"Just Bliv Oversized Tee",category:"tees",price:22000,tag:"NEW DROP",desc:"Relaxed fit · Street essential",image:"https://images.unsplash.com/photo-1503341504253-dff4815485f1?auto=format&fit=crop&w=800&q=85"},
  {id:3,name:"JB Studio Long Sleeve",category:"tops",price:26000,tag:"STUDIO PICK",desc:"A clean everyday layer",image:"https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=800&q=85"},
  {id:4,name:"Custom Print Tee",category:"tees",price:25000,tag:"CUSTOM",desc:"Make the design your own",image:"https://images.unsplash.com/photo-1562157873-818bc0726f68?auto=format&fit=crop&w=800&q=85"},
  {id:5,name:"JB Essential Hoodie",category:"tops",price:38000,tag:"LIMITED",desc:"Comfort with character",image:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=800&q=85"},
  {id:6,name:"Everyday Street Cap",category:"accessories",price:12000,tag:"DAILY ROTATION",desc:"Finish the fit",image:"https://images.unsplash.com/photo-1521369934308-5af4b0b7b9e6?auto=format&fit=crop&w=800&q=85"},
  {id:7,name:"JB Graphic Sweatshirt",category:"tops",price:32000,tag:"JUST BLIV",desc:"Statement comfort",image:"https://images.unsplash.com/photo-1578681994506-b8f463449011?auto=format&fit=crop&w=800&q=85"},
  {id:8,name:"Custom Phone Case",category:"accessories",price:9000,tag:"PERSONALISED",desc:"Your style, your details",image:"https://images.unsplash.com/photo-1601593346740-925612772716?auto=format&fit=crop&w=800&q=85"}
];
// Replace any sample product details/images with JB-OUTFIT's confirmed stock and prices.
let cart = [];
const money = n => "₦" + Number(n).toLocaleString("en-NG");
const $ = s => document.querySelector(s);
const grid = $("#productGrid");

function renderProducts(filter="all"){
  const shown = products.filter(p => filter==="all" || p.category===filter);
  grid.innerHTML = shown.map(p=>`<article class="product-card">
    <div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy"><span class="product-tag">${p.tag}</span><button class="add-btn" data-add="${p.id}" aria-label="Add ${p.name} to bag">+</button></div>
    <div class="product-meta"><div><h3>${p.name}</h3><p>${p.desc}</p></div><span class="product-price">${money(p.price)}</span></div>
  </article>`).join("");
}
function addToCart(id){
  const item=cart.find(x=>x.id===id);
  item?item.qty++:cart.push({id,qty:1});
  renderCart();toast("Added to your bag ✳");
}
function renderCart(){
  const count=cart.reduce((n,x)=>n+x.qty,0), total=cart.reduce((n,x)=>n+products.find(p=>p.id===x.id).price*x.qty,0);
  $("#cartCount").textContent=count;$("#drawerCount").textContent=`(${count})`;$("#subtotal").textContent=money(total);$("#checkoutTotal").textContent=money(total);
  $("#cartItems").innerHTML=cart.length?cart.map(x=>{const p=products.find(y=>y.id===x.id);return `<div class="cart-item"><img src="${p.image}" alt=""><div><h4>${p.name}</h4><small>${money(p.price)}</small><div class="qty"><button data-qty="${p.id}" data-change="-1">−</button><span>${x.qty}</span><button data-qty="${p.id}" data-change="1">+</button></div></div><button class="remove" data-remove="${p.id}">REMOVE</button></div>`}).join(""):`<div class="empty-cart">Your bag is waiting for something good. ✳</div>`;
}
function openCart(){ $("#cartDrawer").classList.add("show");$("#cartOverlay").classList.add("show"); }
function closeCart(){ $("#cartDrawer").classList.remove("show");$("#cartOverlay").classList.remove("show"); }
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2100);}
function total(){return cart.reduce((n,x)=>n+products.find(p=>p.id===x.id).price*x.qty,0);}
function orderText(details){
  const lines=cart.map(x=>{const p=products.find(y=>y.id===x.id);return `${p.name} x${x.qty} — ${money(p.price*x.qty)}`}).join("\n");
  return `Hello JB-OUTFIT, I'd like to place an order.\n\n${lines}\n\nTotal: ${money(total())}\nName: ${details.name}\nPhone: ${details.phone}\nEmail: ${details.email}\nDelivery address: ${details.address}`;
}
grid.addEventListener("click",e=>{const b=e.target.closest("[data-add]");if(b)addToCart(Number(b.dataset.add));});
$("#filters").addEventListener("click",e=>{const b=e.target.closest("[data-filter]");if(!b)return;document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderProducts(b.dataset.filter);});
$("#cartOpen").onclick=openCart;$("#cartClose").onclick=closeCart;$("#cartOverlay").onclick=closeCart;$("#continueShopping").onclick=closeCart;
$("#cartItems").addEventListener("click",e=>{
  const q=e.target.closest("[data-qty]"),r=e.target.closest("[data-remove]");
  if(q){const id=Number(q.dataset.qty),item=cart.find(x=>x.id===id);item.qty+=Number(q.dataset.change);if(item.qty<=0)cart=cart.filter(x=>x.id!==id);}
  if(r)cart=cart.filter(x=>x.id!==Number(r.dataset.remove));renderCart();
});
$("#checkoutBtn").onclick=()=>{if(!cart.length){toast("Add a piece to your bag first");return;}closeCart();$("#checkoutModal").classList.add("show");};
$("#checkoutClose").onclick=()=>$("#checkoutModal").classList.remove("show");
$("#checkoutModal").addEventListener("click",e=>{if(e.target.id==="checkoutModal")$("#checkoutModal").classList.remove("show");});
$("#checkoutForm").addEventListener("submit",e=>{
  e.preventDefault();if(!cart.length){toast("Your bag is empty");return;}
  const details=Object.fromEntries(new FormData(e.target).entries());
  if(PAYSTACK_PUBLIC_KEY.includes("REPLACE_WITH")){toast("Store owner: add your Paystack public key in script.js");return;}
  if(typeof PaystackPop==="undefined"){toast("Payment service unavailable. Please try WhatsApp checkout.");return;}
  const handler=PaystackPop.setup({
    key:PAYSTACK_PUBLIC_KEY,email:details.email,amount:total()*100,currency:"NGN",
    ref:"JB"+Date.now(),
    metadata:{custom_fields:[{display_name:"Customer name",variable_name:"customer_name",value:details.name},{display_name:"Phone",variable_name:"phone",value:details.phone},{display_name:"Delivery address",variable_name:"delivery_address",value:details.address}]},
    callback:function(response){
      // IMPORTANT: verify response.reference on your own server before marking any order as paid.
      const msg=encodeURIComponent(orderText(details)+`\n\nPaystack reference: ${response.reference}\nPlease confirm my payment and order.`);
      window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`,"_blank");
      toast("Payment submitted. Please send the order details on WhatsApp.");
    },
    onClose:function(){toast("Payment window closed");}
  });
  handler.openIframe();
});
$("#whatsappCheckout").onclick=()=>{
  if(!cart.length)return;
  const details=Object.fromEntries(new FormData($("#checkoutForm")).entries());
  if(!details.name||!details.phone||!details.address){toast("Please fill in your name, phone and address");return;}
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(orderText(details))}`,"_blank");
};
$("#menuToggle").onclick=()=>$("#nav").classList.toggle("open");
$("#nav").addEventListener("click",e=>{if(e.target.tagName==="A")$("#nav").classList.remove("open");});
$("#year").textContent=new Date().getFullYear();
renderProducts();renderCart();
