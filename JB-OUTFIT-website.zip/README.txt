JB-OUTFIT storefront

FILES
- index.html: page structure
- style.css: responsive styling
- script.js: products, filters, shopping bag and checkout

IMPORTANT BEFORE GOING LIVE
1. In script.js, replace the sample products, sample prices and image URLs with the brand's real products and confirmed prices.
2. Replace PAYSTACK_PUBLIC_KEY with the store owner's Paystack public key.
3. Keep the secret key private. Never put a Paystack secret key in browser JavaScript.
4. Build a small backend/serverless endpoint to verify each Paystack transaction reference before marking an order as paid. The current front-end intentionally does not claim payment is verified.
5. Confirm delivery fees, return policy, sizes and stock with the business.
6. WhatsApp ordering is connected to the number shown in the provided profile screenshot: +234 806 281 5053.

TEST LOCALLY
Open index.html in a browser. Product filtering, add-to-bag, quantity changes and WhatsApp order composition work on the front end. Paystack checkout requires the owner's real public key and server-side verification.

The sample product prices and stock are placeholders, not confirmed JB-OUTFIT prices.
